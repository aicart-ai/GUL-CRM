package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun getBuyerAdvice(
        buyer: Buyer,
        history: List<InteractionHistory>,
        bhattis: List<Bhatti>,
        transporters: List<Transporter>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "⚠️ Gemini API Key missing hai! Please check your AI Studio Secrets Panel or .env file."
        }

        val prompt = buildPrompt(buyer, history, bhattis, transporters)

        try {
            // Build request JSON manually using Android's standard JSONObject
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", prompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                // Optional system instruction
                val systemInstructionObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        val partObj = JSONObject().apply {
                            put("text", "You are an expert CRM consultant and advisor for 'Gur Vyapaar', a Pan-India Jaggery Export Business. You speak in professional, warm, and highly action-oriented Hinglish (Hindi written in Roman/English script) to help the user manage their business single-handedly and maximize profits.")
                        }
                        put(partObj)
                    }
                    put("parts", partsArray)
                }
                put("systemInstruction", systemInstructionObj)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "Gemini API error: Code ${response.code}, Body: $errBody")
                    return@withContext "Error: API call failed with code ${response.code}. Please try again later."
                }

                val resBody = response.body?.string() ?: ""
                val resJson = JSONObject(resBody)
                val candidates = resJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "No advice text received.")
                        }
                    }
                }
                return@withContext "Mujhe is Buyer ke liye suggestions nahi mil paye. Kripya bad me dhyan de."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini call", e)
            return@withContext "Network or Server exception: ${e.localizedMessage}. Internet connection check karein."
        }
    }

    suspend fun chatWithGemini(
        messages: List<ChatMessage>,
        contextInfo: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "⚠️ Gemini API Key missing hai! Please check your AI Studio Secrets Panel or .env file."
        }

        try {
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    messages.forEach { msg ->
                        val roleStr = if (msg.sender == "user") "user" else "model"
                        val contentObj = JSONObject().apply {
                            put("role", roleStr)
                            val partsArray = JSONArray().apply {
                                val partObj = JSONObject().apply {
                                    put("text", msg.text)
                                }
                                put(partObj)
                            }
                            put("parts", partsArray)
                        }
                        put(contentObj)
                    }
                }
                put("contents", contentsArray)

                val systemInstructionObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        val partObj = JSONObject().apply {
                            put("text", """
                                You are 'Gur Vyapaar Mitra', an AI Business Advisor for a Pan-India Jaggery Export Business. 
                                Talk to the user in a very motivating, highly professional, and friendly Hinglish (Hindi written in Roman/English script) or clean Hindi. Use good business-oriented emojis.
                                Help them optimize their profit, design buyer pitches, check routes, and give tasks to grow their business.
                                
                                Here is the current real-time state of their business database (Context):
                                $contextInfo
                                
                                Respond to the user's latest query using this context. Be extremely action-oriented. 
                                If the user asks for a task or a way to grow, formulate a solid task (with a title, description, and target date) that is directly relevant to their current business state (e.g. following up with a buyer, checking on stock at a bhatti, or completing an order).
                            """.trimIndent())
                        }
                        put(partObj)
                    }
                    put("parts", partsArray)
                }
                put("systemInstruction", systemInstructionObj)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "Gemini Chat API error: Code ${response.code}, Body: $errBody")
                    return@withContext "Error: API call failed with code ${response.code}."
                }

                val resBody = response.body?.string() ?: ""
                val resJson = JSONObject(resBody)
                val candidates = resJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "")
                        }
                    }
                }
                return@withContext "Aapka message mil gaya hai, lekin response generate karne me thodi dikkat hui."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini Chat call", e)
            return@withContext "Network or Server exception: ${e.localizedMessage}. Internet connection check karein."
        }
    }

    suspend fun generateGrowthTask(
        contextInfo: String,
        todayDate: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "ERROR: API KEY MISSING"
        }

        try {
            val prompt = """
                Based on the current state of my Jaggery Export Business CRM, generate ONE high-priority, strategic daily task to grow my business rapidly.
                The task should be highly practical, specific, and achievable in one day (e.g. following up with a buyer who hasn't been contacted, checking stock levels at a bhatti, asking for rate sheets from logistics, pitch organic cubes to sweet manufacturer).

                --- CURRENT DATABASE CONTEXT ---
                $contextInfo

                --- TODAY'S DATE ---
                $todayDate

                You MUST return ONLY a raw JSON object containing exactly the following keys, with NO markdown formatting, NO backticks, and NO extra text:
                {
                  "title": "A short, catchy, action-oriented task title in Hinglish with an emoji (e.g., '📞 Rajesh Gupta Deal Pitch')",
                  "description": "A highly motivating, detailed description in Hinglish explaining EXACTLY what to do, which buyer/bhatti to target, and how this will help grow the business.",
                  "date": "$todayDate",
                  "relatedType": "General"
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", prompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext "ERROR: API failed with code ${response.code}"
                }

                val resBody = response.body?.string() ?: ""
                val resJson = JSONObject(resBody)
                val candidates = resJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            var text = parts.getJSONObject(0).optString("text", "").trim()
                            // Strip markdown code block wrappers if generated
                            if (text.startsWith("```json")) {
                                text = text.removePrefix("```json")
                            }
                            if (text.startsWith("```")) {
                                text = text.removePrefix("```")
                            }
                            if (text.endsWith("```")) {
                                text = text.removeSuffix("```")
                            }
                            return@withContext text.trim()
                        }
                    }
                }
                return@withContext "ERROR: Empty response"
            }
        } catch (e: Exception) {
            return@withContext "ERROR: ${e.localizedMessage}"
        }
    }

    private fun buildPrompt(
        buyer: Buyer,
        history: List<InteractionHistory>,
        bhattis: List<Bhatti>,
        transporters: List<Transporter>
    ): String {
        val historyText = if (history.isEmpty()) {
            "Abhi tak koi interaction history nahi hai."
        } else {
            history.joinToString("\n") { "- ${it.text}" }
        }

        val bhattisText = if (bhattis.isEmpty()) {
            "Koi Bhatti available nahi hai system me."
        } else {
            bhattis.joinToString("\n") {
                "- Name: ${it.name}, Type: ${it.jaggeryType}, Stock: ${it.stockTonnes} tonnes, Price: Rs. ${it.ratePerKg}/Kg, Loc: ${it.location}"
            }
        }

        val transportersText = if (transporters.isEmpty()) {
            "Koi Transporter list me nahi hai."
        } else {
            transporters.joinToString("\n") {
                "- ${it.companyName} (Routes: ${it.routes}), Rate/Km: Rs. ${it.ratePerKm}, Rate/Tonne: Rs. ${it.ratePerTonne}"
            }
        }

        return """
            Mere is Buyer ke liye mujhe solid sales strategy, quotation suggestions, aur negotiation advice chahiye.

            --- BUYER DETAILS ---
            - Name: ${buyer.name}
            - Phone: ${buyer.phone}
            - Location: ${buyer.location}
            - Category: ${buyer.category}
            - Preferred Jaggery Type: ${buyer.preferredType}
            - Notes: ${buyer.notes}

            --- PREVIOUS CONVERSATION HISTORY ---
            $historyText

            --- AVAILABLE BHATTIS (SUPPLIERS) ---
            $bhattisText

            --- AVAILABLE TRANSPORTERS ---
            $transportersText

            Kripya mujhe detail me batayein in Hinglish:
            1. **Matching Jaggery Supply**: Is buyer ke preferred type ($ {buyer.preferredType}) ke liye kaunsi Bhatti sabse best match hai? (Price aur stock ko compare karke batayein).
            2. **Best Shipping Route & Estimated Cost**: Kaunsa transporter is route (${buyer.location}) ke liye sahi rahega aur transport cost kya ho sakti hai?
            3. **Suggested Quote Price**: Bhatti rate aur transport rate ko dekh kar buyer ko kya rate (Rs. per Kg) offer karna chahiye jisme mujhe maximum profit mile aur buyer bhi khush rahe?
            4. **Negotiation and Handling Strategy**: Is buyer ko kaise handle karein, kaise satisfy karein aur follow-up kaise karein taki deal final ho jaye? (Solopreneur ke perspective se points dein).

            Keep the tone motivating, highly professional, business-focused, and in clean, readable Hinglish script (Roman script/Hindi in English letters). Use nice emojis for headings!
        """.trimIndent()
    }
}
