package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BuyerDao {
    @Query("SELECT * FROM buyers ORDER BY name ASC")
    fun getBuyers(): Flow<List<Buyer>>

    @Query("SELECT * FROM buyers WHERE id = :id")
    suspend fun getBuyerById(id: Int): Buyer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(buyer: Buyer): Long

    @Update
    suspend fun update(buyer: Buyer)

    @Delete
    suspend fun delete(buyer: Buyer)
}

@Dao
interface InteractionDao {
    @Query("SELECT * FROM interaction_histories WHERE buyerId = :buyerId ORDER BY timestamp DESC")
    fun getHistoryForBuyer(buyerId: Int): Flow<List<InteractionHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(history: InteractionHistory)

    @Delete
    suspend fun delete(history: InteractionHistory)
}

@Dao
interface BhattiDao {
    @Query("SELECT * FROM bhattis ORDER BY name ASC")
    fun getBhattis(): Flow<List<Bhatti>>

    @Query("SELECT * FROM bhattis WHERE id = :id")
    suspend fun getBhattiById(id: Int): Bhatti?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bhatti: Bhatti): Long

    @Update
    suspend fun update(bhatti: Bhatti)

    @Delete
    suspend fun delete(bhatti: Bhatti)
}

@Dao
interface TransporterDao {
    @Query("SELECT * FROM transporters ORDER BY companyName ASC")
    fun getTransporters(): Flow<List<Transporter>>

    @Query("SELECT * FROM transporters WHERE id = :id")
    suspend fun getTransporterById(id: Int): Transporter?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transporter: Transporter): Long

    @Update
    suspend fun update(transporter: Transporter)

    @Delete
    suspend fun delete(transporter: Transporter)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY orderDate DESC")
    fun getOrders(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(order: Order): Long

    @Update
    suspend fun update(order: Order)

    @Delete
    suspend fun delete(order: Order)
}

@Dao
interface FollowUpDao {
    @Query("SELECT * FROM follow_ups ORDER BY date ASC")
    fun getFollowUps(): Flow<List<FollowUp>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(followUp: FollowUp)

    @Update
    suspend fun update(followUp: FollowUp)

    @Delete
    suspend fun delete(followUp: FollowUp)
}

@Dao
interface SeasonTargetDao {
    @Query("SELECT * FROM season_targets LIMIT 1")
    fun getTargetFlow(): Flow<SeasonTarget?>

    @Query("SELECT * FROM season_targets LIMIT 1")
    suspend fun getTarget(): SeasonTarget?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(target: SeasonTarget)

    @Update
    suspend fun update(target: SeasonTarget)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getChatMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChat()
}

