package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "buyers")
data class Buyer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val location: String,
    val category: String, // e.g. "Wholesaler", "Retailer", "Sweet Manufacturer", "Exporter"
    val preferredType: String, // e.g. "Organic Cubes", "Golden Powder", "Dark Solid"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "interaction_histories")
data class InteractionHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val buyerId: Int,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bhattis")
data class Bhatti(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val ownerName: String,
    val phone: String,
    val location: String,
    val jaggeryType: String, // e.g. "Organic Cubes", "Chemical-Free", "Golden Yellow", "Dark Brown", "Jaggery Powder"
    val stockTonnes: Double,
    val ratePerKg: Double,
    val notes: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "transporters")
data class Transporter(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val companyName: String,
    val contactName: String,
    val phone: String,
    val routes: String, // e.g. "Kolhapur to Delhi", "Sangli to Mumbai"
    val ratePerKm: Double,
    val ratePerTonne: Double,
    val notes: String = ""
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val buyerId: Int,
    val bhattiId: Int,
    val transporterId: Int,
    val quantityTonnes: Double,
    val buyingRatePerKg: Double,
    val sellingRatePerKg: Double,
    val transportCost: Double,
    val otherExpenses: Double = 0.0,
    val status: String, // "Pending", "In-Transit", "Delivered", "Cancelled"
    val orderDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "follow_ups")
data class FollowUp(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String = "",
    val date: String, // YYYY-MM-DD
    val isCompleted: Boolean = false,
    val relatedType: String, // "Buyer", "Bhatti", "Transporter", "General"
    val relatedId: Int = 0
)

@Entity(tableName = "season_targets")
data class SeasonTarget(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val targetTonnes: Double,
    val currentProgressTonnes: Double = 0.0,
    val year: String = "2026-2027"
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val sender: String, // "user" or "ai"
    val timestamp: Long = System.currentTimeMillis()
)

