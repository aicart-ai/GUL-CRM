package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Buyer::class,
        InteractionHistory::class,
        Bhatti::class,
        Transporter::class,
        Order::class,
        FollowUp::class,
        SeasonTarget::class,
        ChatMessage::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun buyerDao(): BuyerDao
    abstract fun interactionDao(): InteractionDao
    abstract fun bhattiDao(): BhattiDao
    abstract fun transporterDao(): TransporterDao
    abstract fun orderDao(): OrderDao
    abstract fun followUpDao(): FollowUpDao
    abstract fun seasonTargetDao(): SeasonTargetDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jaggery_crm_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
