package com.example.data

import kotlinx.coroutines.flow.Flow

class JaggeryRepository(private val db: AppDatabase) {
    val buyers: Flow<List<Buyer>> = db.buyerDao().getBuyers()
    val bhattis: Flow<List<Bhatti>> = db.bhattiDao().getBhattis()
    val transporters: Flow<List<Transporter>> = db.transporterDao().getTransporters()
    val orders: Flow<List<Order>> = db.orderDao().getOrders()
    val followUps: Flow<List<FollowUp>> = db.followUpDao().getFollowUps()
    val seasonTargetFlow: Flow<SeasonTarget?> = db.seasonTargetDao().getTargetFlow()
    val chatMessages: Flow<List<ChatMessage>> = db.chatMessageDao().getChatMessages()

    // Buyers
    suspend fun insertBuyer(buyer: Buyer): Long = db.buyerDao().insert(buyer)
    suspend fun updateBuyer(buyer: Buyer) = db.buyerDao().update(buyer)
    suspend fun deleteBuyer(buyer: Buyer) = db.buyerDao().delete(buyer)
    suspend fun getBuyerById(id: Int): Buyer? = db.buyerDao().getBuyerById(id)

    // Interaction Histories
    fun getHistoryForBuyer(buyerId: Int): Flow<List<InteractionHistory>> =
        db.interactionDao().getHistoryForBuyer(buyerId)
    suspend fun insertHistory(history: InteractionHistory) = db.interactionDao().insert(history)
    suspend fun deleteHistory(history: InteractionHistory) = db.interactionDao().delete(history)

    // Bhatti
    suspend fun insertBhatti(bhatti: Bhatti): Long = db.bhattiDao().insert(bhatti)
    suspend fun updateBhatti(bhatti: Bhatti) = db.bhattiDao().update(bhatti)
    suspend fun deleteBhatti(bhatti: Bhatti) = db.bhattiDao().delete(bhatti)
    suspend fun getBhattiById(id: Int): Bhatti? = db.bhattiDao().getBhattiById(id)

    // Transporters
    suspend fun insertTransporter(transporter: Transporter): Long = db.transporterDao().insert(transporter)
    suspend fun updateTransporter(transporter: Transporter) = db.transporterDao().update(transporter)
    suspend fun deleteTransporter(transporter: Transporter) = db.transporterDao().delete(transporter)
    suspend fun getTransporterById(id: Int): Transporter? = db.transporterDao().getTransporterById(id)

    // Orders
    suspend fun insertOrder(order: Order): Long = db.orderDao().insert(order)
    suspend fun updateOrder(order: Order) = db.orderDao().update(order)
    suspend fun deleteOrder(order: Order) = db.orderDao().delete(order)

    // Follow ups
    suspend fun insertFollowUp(followUp: FollowUp) = db.followUpDao().insert(followUp)
    suspend fun updateFollowUp(followUp: FollowUp) = db.followUpDao().update(followUp)
    suspend fun deleteFollowUp(followUp: FollowUp) = db.followUpDao().delete(followUp)

    // Season Target
    suspend fun getSeasonTarget(): SeasonTarget? = db.seasonTargetDao().getTarget()
    suspend fun updateSeasonTarget(target: SeasonTarget) = db.seasonTargetDao().update(target)
    suspend fun insertSeasonTarget(target: SeasonTarget) = db.seasonTargetDao().insert(target)

    // Chat Messages
    suspend fun insertChatMessage(message: ChatMessage): Long = db.chatMessageDao().insert(message)
    suspend fun clearChat() = db.chatMessageDao().clearChat()
}
