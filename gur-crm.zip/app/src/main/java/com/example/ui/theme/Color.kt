package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Jaggery (Gur) Organic Palette
val JaggeryBrown = Color(0xFF8B5A2B)         // Main primary, rich caramel brown
val GoldenHoney = Color(0xFFC77C1E)          // Secondary accent, golden amber
val CreamyIvory = Color(0xFFFAF6EE)          // Main light background
val WarmMilk = Color(0xFFFFFDF9)             // Card surface background
val DarkJaggery = Color(0xFF2D1E18)          // Dark text / primary dark surface

// Light Theme Specs
val PrimaryLight = Color(0xFF8B5A2B)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFBE9D8)
val OnPrimaryContainerLight = Color(0xFF3B1E05)
val SecondaryLight = Color(0xFFC77C1E)
val OnSecondaryLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFFAF6EE)
val SurfaceLight = Color(0xFFFFFDF9)
val OnBackgroundLight = Color(0xFF2D1E18)
val OnSurfaceLight = Color(0xFF2D1E18)

// Dark Theme Specs (Deep Dark Chocolate)
val PrimaryDark = Color(0xFFF5BE90)
val OnPrimaryDark = Color(0xFF4E2D00)
val PrimaryContainerDark = Color(0xFF703D00)
val OnPrimaryContainerDark = Color(0xFFFFDDB8)
val SecondaryDark = Color(0xFFFFB85E)
val OnSecondaryDark = Color(0xFF4A2800)
val BackgroundDark = Color(0xFF1E1511)
val SurfaceDark = Color(0xFF2B1D17)
val OnBackgroundDark = Color(0xFFECE0DB)
val OnSurfaceDark = Color(0xFFECE0DB)
val SurfaceVariantDark = Color(0xFF4F443E)
val OnSurfaceVariantDark = Color(0xFFD2C3BB)
