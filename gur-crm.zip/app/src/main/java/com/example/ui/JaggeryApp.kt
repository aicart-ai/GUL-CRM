package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.text.TextStyle
import android.app.Application
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.*

enum class JaggeryTab(val title: String, val icon: ImageVector) {
    Dashboard("Dashboard", Icons.Default.Dashboard),
    Buyers("Buyers CRM", Icons.Default.People),
    Bhattis("Bhattis", Icons.Default.Storefront),
    Transporters("Logistics", Icons.Default.LocalShipping),
    Orders("Orders", Icons.Default.ShoppingCart),
    Planner("Planner", Icons.Default.CalendarToday),
    AiChat("AI Co-Pilot", Icons.Default.AutoAwesome)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JaggeryApp(viewModel: MainViewModel) {
    var currentTab by remember { mutableStateOf(JaggeryTab.Dashboard) }
    val context = LocalContext.current

    val buyers by viewModel.buyers.collectAsStateWithLifecycle()
    val bhattis by viewModel.bhattis.collectAsStateWithLifecycle()
    val transporters by viewModel.transporters.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val followUps by viewModel.followUps.collectAsStateWithLifecycle()
    val seasonTarget by viewModel.seasonTarget.collectAsStateWithLifecycle()

    // Dialog state controllers
    var showAddBuyer by remember { mutableStateOf(false) }
    var showAddBhatti by remember { mutableStateOf(false) }
    var showAddTransporter by remember { mutableStateOf(false) }
    var showAddOrder by remember { mutableStateOf(false) }
    var showAddFollowUp by remember { mutableStateOf(false) }
    var showEditTarget by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Gur Vyapaar CRM",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    if (buyers.isEmpty() && bhattis.isEmpty() && transporters.isEmpty()) {
                        Button(
                            onClick = {
                                viewModel.prepopulateSampleData()
                                Toast.makeText(context, "Sample Jaggery Export Data loaded!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Demo Data Load", fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                JaggeryTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            when (currentTab) {
                JaggeryTab.Buyers -> {
                    FloatingActionButton(
                        onClick = { showAddBuyer = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_buyer_fab")
                    ) { Icon(Icons.Default.Add, "Add Buyer") }
                }
                JaggeryTab.Bhattis -> {
                    FloatingActionButton(
                        onClick = { showAddBhatti = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_bhatti_fab")
                    ) { Icon(Icons.Default.Add, "Add Bhatti") }
                }
                JaggeryTab.Transporters -> {
                    FloatingActionButton(
                        onClick = { showAddTransporter = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_transporter_fab")
                    ) { Icon(Icons.Default.Add, "Add Transporter") }
                }
                JaggeryTab.Orders -> {
                    FloatingActionButton(
                        onClick = { showAddOrder = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_order_fab")
                    ) { Icon(Icons.Default.Add, "Add Order") }
                }
                JaggeryTab.Planner -> {
                    FloatingActionButton(
                        onClick = { showAddFollowUp = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("add_followup_fab")
                    ) { Icon(Icons.Default.Add, "Add Follow-up") }
                }
                else -> {}
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "TabTransition"
            ) { targetTab ->
                when (targetTab) {
                    JaggeryTab.Dashboard -> DashboardScreen(
                        viewModel = viewModel,
                        buyers = buyers,
                        bhattis = bhattis,
                        transporters = transporters,
                        orders = orders,
                        followUps = followUps,
                        seasonTarget = seasonTarget,
                        onEditTargetClick = { showEditTarget = true },
                        onNavigateToTab = { currentTab = it }
                    )
                    JaggeryTab.Buyers -> BuyersScreen(
                        viewModel = viewModel,
                        buyers = buyers,
                        bhattis = bhattis,
                        transporters = transporters
                    )
                    JaggeryTab.Bhattis -> BhattisScreen(
                        viewModel = viewModel,
                        bhattis = bhattis
                    )
                    JaggeryTab.Transporters -> TransportersScreen(
                        viewModel = viewModel,
                        transporters = transporters,
                        bhattis = bhattis,
                        buyers = buyers
                    )
                    JaggeryTab.Orders -> OrdersScreen(
                        viewModel = viewModel,
                        orders = orders,
                        buyers = buyers,
                        bhattis = bhattis,
                        transporters = transporters
                    )
                    JaggeryTab.Planner -> PlannerScreen(
                        viewModel = viewModel,
                        followUps = followUps,
                        buyers = buyers,
                        bhattis = bhattis,
                        transporters = transporters,
                        seasonTarget = seasonTarget,
                        onEditTargetClick = { showEditTarget = true }
                    )
                    JaggeryTab.AiChat -> AiChatScreen(viewModel = viewModel)
                }
            }
        }
    }

    // --- Dialog Modals ---
    if (showAddBuyer) {
        AddBuyerDialog(
            onDismiss = { showAddBuyer = false },
            onConfirm = { name, phone, location, category, prefType, notes ->
                viewModel.addBuyer(name, phone, location, category, prefType, notes)
                showAddBuyer = false
            }
        )
    }

    if (showAddBhatti) {
        AddBhattiDialog(
            onDismiss = { showAddBhatti = false },
            onConfirm = { name, owner, phone, location, jType, stock, rate, notes ->
                viewModel.addBhatti(name, owner, phone, location, jType, stock, rate, notes)
                showAddBhatti = false
            }
        )
    }

    if (showAddTransporter) {
        AddTransporterDialog(
            onDismiss = { showAddTransporter = false },
            onConfirm = { name, contact, phone, routes, rateKm, rateTonne, notes ->
                viewModel.addTransporter(name, contact, phone, routes, rateKm, rateTonne, notes)
                showAddTransporter = false
            }
        )
    }

    if (showAddOrder) {
        AddOrderDialog(
            onDismiss = { showAddOrder = false },
            buyers = buyers,
            bhattis = bhattis,
            transporters = transporters,
            onConfirm = { buyerId, bhattiId, transId, qty, buyR, sellR, tCost, other ->
                viewModel.addOrder(buyerId, bhattiId, transId, qty, buyR, sellR, tCost, other)
                showAddOrder = false
            }
        )
    }

    if (showAddFollowUp) {
        AddFollowUpDialog(
            onDismiss = { showAddFollowUp = false },
            buyers = buyers,
            bhattis = bhattis,
            transporters = transporters,
            onConfirm = { title, desc, date, relType, relId ->
                viewModel.addFollowUp(title, desc, date, relType, relId)
                showAddFollowUp = false
            }
        )
    }

    if (showEditTarget) {
        EditTargetDialog(
            currentTarget = seasonTarget?.targetTonnes ?: 500.0,
            onDismiss = { showEditTarget = false },
            onConfirm = { newTarget ->
                viewModel.updateSeasonTargetValue(newTarget)
                showEditTarget = false
            }
        )
    }
}

// ==========================================
// SCREEN: DASHBOARD
// ==========================================
@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>,
    orders: List<Order>,
    followUps: List<FollowUp>,
    seasonTarget: SeasonTarget?,
    onEditTargetClick: () -> Unit,
    onNavigateToTab: (JaggeryTab) -> Unit
) {
    val scrollState = rememberScrollState()

    // Calculate core metrics
    val totalSalesTonnes = orders.filter { it.status == "Delivered" || it.status == "In-Transit" }.sumOf { it.quantityTonnes }
    val revenue = orders.filter { it.status == "Delivered" || it.status == "In-Transit" }.sumOf {
        it.quantityTonnes * 1000 * it.sellingRatePerKg
    }
    val buyCost = orders.filter { it.status == "Delivered" || it.status == "In-Transit" }.sumOf {
        it.quantityTonnes * 1000 * it.buyingRatePerKg
    }
    val freightCost = orders.filter { it.status == "Delivered" || it.status == "In-Transit" }.sumOf {
        it.transportCost + it.otherExpenses
    }
    val estimatedProfit = revenue - (buyCost + freightCost)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header with beautiful gradient background
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = "Ram Ram! Swagat Hai 🙏",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Apne Pan-India Jaggery Export business ko akele sambhalein aur munafa badhayein.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Season Target Progress Card
        val target = seasonTarget?.targetTonnes ?: 500.0
        val progress = seasonTarget?.currentProgressTonnes ?: 0.0
        val fraction = if (target > 0) (progress / target).toFloat().coerceIn(0f, 1f) else 0f

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Season Export Target 🎯", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Year: ${seasonTarget?.year ?: "2026-2027"}", fontSize = 12.sp, color = Color.Gray)
                    }
                    IconButton(onClick = onEditTargetClick) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Target", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                    color = MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.secondaryContainer
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${String.format(Locale.US, "%.1f", progress)} T exported",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.1f", target)} T Target",
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "${(fraction * 100).toInt()}% completed",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Stats Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Total Export", fontSize = 12.sp, color = Color.Gray)
                    Text(
                        text = "${String.format(Locale.US, "%.1f", totalSalesTonnes)} Tonnes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text("In-Transit / Delivered", fontSize = 10.sp, color = Color.Gray)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Estimated Profit", fontSize = 12.sp, color = Color.Gray)
                    Text(
                        text = "₹${String.format(Locale.US, "%,.0f", estimatedProfit)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF2E7D32)
                    )
                    Text("Net after costs", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        // Today's Follow-up list
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val todaysFollowups = followUps.filter { !it.isCompleted } // filter for active ones

        Text("Today's Tasks & Follow-ups 📅", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)

        if (todaysFollowups.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Waah! Aaj ke sabhi follow-ups completed hain. Naye task create karne ke liye Planner tab me jayein.",
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        color = Color.Gray
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                todaysFollowups.take(3).forEach { fu ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .clickable { viewModel.toggleFollowUpCompleted(fu) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (fu.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = null,
                            tint = if (fu.isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fu.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (fu.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                            )
                            if (fu.description.isNotEmpty()) {
                                Text(
                                    text = fu.description,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = when (fu.relatedType) {
                                            "Buyer" -> MaterialTheme.colorScheme.primaryContainer
                                            "Bhatti" -> MaterialTheme.colorScheme.secondaryContainer
                                            else -> MaterialTheme.colorScheme.tertiaryContainer
                                        }
                                    ),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(
                                        fu.relatedType,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Date: ${fu.date}",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
                if (todaysFollowups.size > 3) {
                    TextButton(
                        onClick = { onNavigateToTab(JaggeryTab.Planner) },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("View all (${todaysFollowups.size}) Planner tasks")
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Solopreneur Motivation Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Akele kaam karne ka sabse bada faayda: Koi heavy staff cost nahi! Is CRM me Buyer, Supplier, aur Logistics ki details update rakhein aur AI Assistant ko perfect deal pitch design karne dein.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ==========================================
// SCREEN: BUYERS CRM
// ==========================================
@Composable
fun BuyersScreen(
    viewModel: MainViewModel,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var expandedBuyerId by remember { mutableStateOf<Int?>(null) }

    val categories = listOf("All", "Wholesaler", "Retailer", "Sweet Manufacturer", "Food Industry")

    val filteredBuyers = buyers.filter {
        (selectedCategory == "All" || it.category == selectedCategory) &&
                (it.name.contains(searchQuery, ignoreCase = true) ||
                        it.location.contains(searchQuery, ignoreCase = true) ||
                        it.phone.contains(searchQuery))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search & Filters
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buyer Name, Location, Phone search karein...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("buyer_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal Category Filter
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredBuyers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.People,
                        contentDescription = null,
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Koi Buyers nahi mile!", color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("Naya buyer add karne ke liye + button dabayein.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredBuyers) { buyer ->
                    BuyerCard(
                        buyer = buyer,
                        viewModel = viewModel,
                        isExpanded = expandedBuyerId == buyer.id,
                        onExpandClick = {
                            if (expandedBuyerId == buyer.id) {
                                expandedBuyerId = null
                                viewModel.selectBuyer(null)
                            } else {
                                expandedBuyerId = buyer.id
                                viewModel.selectBuyer(buyer.id)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BuyerCard(
    buyer: Buyer,
    viewModel: MainViewModel,
    isExpanded: Boolean,
    onExpandClick: () -> Unit
) {
    val context = LocalContext.current
    val history by viewModel.activeBuyerHistory.collectAsStateWithLifecycle()
    val aiAdviceState by viewModel.aiAdviceState.collectAsStateWithLifecycle()

    var newHistoryText by remember { mutableStateOf("") }
    var showAiAdviceDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("buyer_card_${buyer.id}")
            .animateContentSize(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isExpanded) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
        ),
        border = if (isExpanded) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = buyer.name.take(1).uppercase(),
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = buyer.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = buyer.location, fontSize = 12.sp, color = Color.Gray)
                    }
                }

                IconButton(onClick = onExpandClick) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand/Collapse",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub header chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = buyer.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "Pref: ${buyer.preferredType}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(12.dp))

                // Action panel: Call and Notes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Phone: ${buyer.phone}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )

                    Row {
                        IconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${buyer.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = "Call", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Smart AI advisor Trigger Button
                        Button(
                            onClick = {
                                viewModel.getSmartAdviceForBuyer(buyer)
                                showAiAdviceDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Smart AI Advice", fontSize = 12.sp)
                        }
                    }
                }

                if (buyer.notes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Notes:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                            Text(buyer.notes, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("Conversation Logs & History 💬", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))

                // New log insertion
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newHistoryText,
                        onValueChange = { newHistoryText = it },
                        placeholder = { Text("Talk history log karein (e.g., call done, prices discussed...)") },
                        modifier = Modifier.weight(1f),
                        textStyle = TextStyle(fontSize = 13.sp),
                        shape = RoundedCornerShape(8.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (newHistoryText.trim().isNotEmpty()) {
                                viewModel.addInteraction(buyer.id, newHistoryText.trim())
                                newHistoryText = ""
                            }
                        },
                        modifier = Modifier.background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Save Log", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // History logs list
                if (history.isEmpty()) {
                    Text(
                        text = "Koi call history recorded nahi hai. Aaj hui baat ko upar likh kar save karein.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        history.forEach { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    val formattedTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(log.timestamp))
                                    Text(text = formattedTime, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    Text(text = log.text, fontSize = 12.sp)
                                }
                                IconButton(onClick = { viewModel.deleteInteraction(log) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                TextButton(
                    onClick = { viewModel.deleteBuyer(buyer) },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete Buyer", fontSize = 12.sp)
                }
            }
        }
    }

    // AI advice output dialog
    if (showAiAdviceDialog) {
        Dialog(onDismissRequest = {
            showAiAdviceDialog = false
            viewModel.clearAdvice()
        }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Smart AI Deal-Maker 💡", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        IconButton(onClick = {
                            showAiAdviceDialog = false
                            viewModel.clearAdvice()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (val state = aiAdviceState) {
                            is AiAdviceState.Idle -> {
                                Text("No advice fetched yet.")
                            }
                            is AiAdviceState.Loading -> {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Bhattis, shipping rates aur buyer pref analyze kiya ja raha hai...", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                                }
                            }
                            is AiAdviceState.Success -> {
                                Text(
                                    text = state.advice,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                            is AiAdviceState.Error -> {
                                Text(
                                    text = "Dhyan dein:\n${state.message}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }
                    Button(
                        onClick = {
                            showAiAdviceDialog = false
                            viewModel.clearAdvice()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) {
                        Text("Sahi hai, pitch tayyar hai!")
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: BHATTIS (SUPPLY STOCK)
// ==========================================
@Composable
fun BhattisScreen(
    viewModel: MainViewModel,
    bhattis: List<Bhatti>
) {
    var searchQuery by remember { mutableStateOf("") }
    val context = LocalContext.current

    val filteredBhattis = bhattis.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.jaggeryType.contains(searchQuery, ignoreCase = true) ||
                it.location.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Bhatti Name, Jaggery Type, or Location search karein...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("bhatti_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredBhattis.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Storefront,
                        contentDescription = null,
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Koi Jaggery Bhatti units nahi mile!", color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("Naye Bhatti units add karne ke liye + button dabayein.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredBhattis) { bhatti ->
                    var showUpdateStockDialog by remember { mutableStateOf(false) }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bhatti_card_${bhatti.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(bhatti.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("Owner: ${bhatti.ownerName}", fontSize = 13.sp, color = Color.Gray)
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(bhatti.location, fontSize = 12.sp, color = Color.Gray)
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${bhatti.phone}"))
                                            context.startActivity(intent)
                                        },
                                        modifier = Modifier.background(MaterialTheme.colorScheme.secondaryContainer, CircleShape)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = "Call", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    IconButton(onClick = { viewModel.deleteBhatti(bhatti) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Bhatti", tint = Color.LightGray)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Details Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Jaggery Type", fontSize = 11.sp, color = Color.Gray)
                                    Text(bhatti.jaggeryType, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Stock Quantity", fontSize = 11.sp, color = Color.Gray)
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                    ) {
                                        Text(
                                            "${bhatti.stockTonnes} Tonnes",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Bhatti Rate", fontSize = 11.sp, color = Color.Gray)
                                    Text("₹${bhatti.ratePerKg}/Kg", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.secondary)
                                }
                            }

                            if (bhatti.notes.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Note: ${bhatti.notes}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { showUpdateStockDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Update Stock & Rate", fontSize = 12.sp)
                            }
                        }
                    }

                    if (showUpdateStockDialog) {
                        UpdateStockDialog(
                            bhatti = bhatti,
                            onDismiss = { showUpdateStockDialog = false },
                            onConfirm = { updatedBhatti ->
                                viewModel.updateBhatti(updatedBhatti)
                                showUpdateStockDialog = false
                            }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: TRANSPORTERS (LOGISTICS CALCULATOR)
// ==========================================
@Composable
fun TransportersScreen(
    viewModel: MainViewModel,
    transporters: List<Transporter>,
    bhattis: List<Bhatti>,
    buyers: List<Buyer>
) {
    var searchQuery by remember { mutableStateOf("") }
    var activeCalculatorTab by remember { mutableStateOf(false) }

    val filteredTransporters = transporters.filter {
        it.companyName.contains(searchQuery, ignoreCase = true) ||
                it.routes.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Toggle tabs inside Logistics page
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activeCalculatorTab = false },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!activeCalculatorTab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (!activeCalculatorTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Transporters Directory", fontSize = 12.sp)
            }

            Button(
                onClick = { activeCalculatorTab = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeCalculatorTab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (activeCalculatorTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bhada/Freight Calculator", fontSize = 12.sp)
            }
        }

        if (!activeCalculatorTab) {
            // Directory View
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Transporter Name or Route search karein...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transporter_search_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredTransporters.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.LocalShipping,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Koi Transport Company nahi mili!", color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text("Naye transporters add karne ke liye + button dabayein.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredTransporters) { transporter ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("transporter_card_${transporter.id}"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(transporter.companyName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text("Contact: ${transporter.contactName}", fontSize = 12.sp, color = Color.Gray)
                                    }

                                    Row {
                                        val context = LocalContext.current
                                        IconButton(
                                            onClick = {
                                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${transporter.phone}"))
                                                context.startActivity(intent)
                                            },
                                            modifier = Modifier.background(MaterialTheme.colorScheme.secondaryContainer, CircleShape)
                                        ) {
                                            Icon(Icons.Default.Phone, contentDescription = "Call", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        IconButton(onClick = { viewModel.deleteTransporter(transporter) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Transporter", tint = Color.LightGray)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = "Routes: ${transporter.routes}",
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Per Km Bhada", fontSize = 11.sp, color = Color.Gray)
                                        Text("₹${transporter.ratePerKm}/Km", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Per Tonne Bhada", fontSize = 11.sp, color = Color.Gray)
                                        Text("₹${transporter.ratePerTonne}/Tonne", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }

                                if (transporter.notes.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Notes: ${transporter.notes}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Freight Calculator View
            FreightCalculator(bhattis = bhattis, buyers = buyers, transporters = transporters)
        }
    }
}

@Composable
fun FreightCalculator(
    bhattis: List<Bhatti>,
    buyers: List<Buyer>,
    transporters: List<Transporter>
) {
    var selectedBhatti by remember { mutableStateOf<Bhatti?>(null) }
    var selectedBuyer by remember { mutableStateOf<Buyer?>(null) }
    var selectedTransporter by remember { mutableStateOf<Transporter?>(null) }
    var quantityInput by remember { mutableStateOf("") }
    var distanceInput by remember { mutableStateOf("") }

    var calcBhattiExpanded by remember { mutableStateOf(false) }
    var calcBuyerExpanded by remember { mutableStateOf(false) }
    var calcTransporterExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Bhada Aur Quotation Calculator 🚚", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            Text("Apne buyer ko sahi rate batane ke liye details daalein. Bhatti rate, cargo quantity, aur transporter charge ke hisab se exact profit margin nikaalein.", fontSize = 12.sp, color = Color.Gray)

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Select Bhatti
            Text("1. Bhatti Select Karein (Supply Source)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { calcBhattiExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(selectedBhatti?.name ?: "Bhatti Select Karein")
                }
                DropdownMenu(expanded = calcBhattiExpanded, onDismissRequest = { calcBhattiExpanded = false }) {
                    bhattis.forEach { b ->
                        DropdownMenuItem(
                            text = { Text("${b.name} (${b.jaggeryType} - ₹${b.ratePerKg}/Kg)") },
                            onClick = {
                                selectedBhatti = b
                                calcBhattiExpanded = false
                            }
                        )
                    }
                }
            }

            // Select Buyer
            Text("2. Buyer Select Karein (Destination)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { calcBuyerExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(selectedBuyer?.name ?: "Buyer Select Karein")
                }
                DropdownMenu(expanded = calcBuyerExpanded, onDismissRequest = { calcBuyerExpanded = false }) {
                    buyers.forEach { b ->
                        DropdownMenuItem(
                            text = { Text("${b.name} (${b.location})") },
                            onClick = {
                                selectedBuyer = b
                                calcBuyerExpanded = false
                            }
                        )
                    }
                }
            }

            // Select Transporter
            Text("3. Transport Company Select Karein", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { calcTransporterExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(selectedTransporter?.companyName ?: "Transporter Select Karein")
                }
                DropdownMenu(expanded = calcTransporterExpanded, onDismissRequest = { calcTransporterExpanded = false }) {
                    transporters.forEach { t ->
                        DropdownMenuItem(
                            text = { Text("${t.companyName} (Rate: ₹${t.ratePerKm}/Km | ₹${t.ratePerTonne}/T)") },
                            onClick = {
                                selectedTransporter = t
                                calcTransporterExpanded = false
                            }
                        )
                    }
                }
            }

            // Numeric Inputs
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = quantityInput,
                    onValueChange = { quantityInput = it },
                    label = { Text("Weight (Tonnes)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )

                OutlinedTextField(
                    value = distanceInput,
                    onValueChange = { distanceInput = it },
                    label = { Text("Approx Distance (Km)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            // Calculations Section
            val qty = quantityInput.toDoubleOrNull() ?: 0.0
            val distance = distanceInput.toDoubleOrNull() ?: 0.0

            if (qty > 0 && selectedBhatti != null && selectedTransporter != null) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(10.dp))

                val bRate = selectedBhatti!!.ratePerKg
                val totalJaggeryCost = qty * 1000 * bRate

                // Calculate freight based on distance and tonnage charges
                val freightByDistance = distance * (selectedTransporter!!.ratePerKm)
                val freightByWeight = qty * (selectedTransporter!!.ratePerTonne)
                val estimatedFreight = freightByDistance + freightByWeight
                val totalDirectCost = totalJaggeryCost + estimatedFreight

                val costPerKg = totalDirectCost / (qty * 1000)

                Text("Cost Summary 📊", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Pure Jaggery Cost (Bhatti Rate):", fontSize = 12.sp)
                            Text("₹${String.format(Locale.US, "%,.0f", totalJaggeryCost)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Freight Cost (Estimated):", fontSize = 12.sp)
                            Text("₹${String.format(Locale.US, "%,.0f", estimatedFreight)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Logistics calculation rule:", fontSize = 11.sp, color = Color.Gray)
                            Text("(Km bhada + weight bhada)", fontSize = 11.sp, color = Color.Gray)
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Base Cost:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("₹${String.format(Locale.US, "%,.0f", totalDirectCost)}", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Net Landing Cost to Exporter:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("₹${String.format(Locale.US, "%.2f", costPerKg)} / Kg", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Suggest quotation
                val suggestQuote3 = costPerKg + 3.0 // ₹3 profit per kg
                val suggestQuote5 = costPerKg + 5.0 // ₹5 profit per kg

                Text("Suggested Quotes to Buyer 💡", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Standard Quote (₹3/Kg margin)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Estimated Profit: ₹${String.format(Locale.US, "%,.0f", qty * 1000 * 3)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("₹${String.format(Locale.US, "%.1f", suggestQuote3)} / Kg", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Premium Quote (₹5/Kg margin)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Estimated Profit: ₹${String.format(Locale.US, "%,.0f", qty * 1000 * 5)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("₹${String.format(Locale.US, "%.1f", suggestQuote5)} / Kg", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Calculations dekhne ke liye Source Bhatti, Transporter, Weight aur Distance enter karein.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

// ==========================================
// SCREEN: ORDERS MANAGEMENT
// ==========================================
@Composable
fun OrdersScreen(
    viewModel: MainViewModel,
    orders: List<Order>,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>
) {
    if (orders.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = Color.LightGray,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Koi Active Orders nahi hain!", color = Color.Gray, fontWeight = FontWeight.Bold)
                Text("Naya export order add karne ke liye + button dabayein.", color = Color.Gray, fontSize = 12.sp)
            }
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            items(orders) { order ->
                val buyer = buyers.find { it.id == order.buyerId }
                val bhatti = bhattis.find { it.id == order.bhattiId }
                val transporter = transporters.find { it.id == order.transporterId }

                var showStatusMenu by remember { mutableStateOf(false) }

                val purchaseCost = order.quantityTonnes * 1000 * order.buyingRatePerKg
                val saleRevenue = order.quantityTonnes * 1000 * order.sellingRatePerKg
                val totalCosts = purchaseCost + order.transportCost + order.otherExpenses
                val profitMargin = saleRevenue - totalCosts

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_card_${order.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "Order #${order.id}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                val orderDateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(order.orderDate))
                                Text(orderDateStr, fontSize = 12.sp, color = Color.Gray)
                            }

                            // Status Chip Clickable
                            Box {
                                Button(
                                    onClick = { showStatusMenu = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when (order.status) {
                                            "Delivered" -> Color(0xFFE8F5E9)
                                            "In-Transit" -> Color(0xFFFFF3E0)
                                            "Cancelled" -> Color(0xFFFFEBEE)
                                            else -> Color(0xFFECEFF1)
                                        },
                                        contentColor = when (order.status) {
                                            "Delivered" -> Color(0xFF2E7D32)
                                            "In-Transit" -> Color(0xFFE65100)
                                            "Cancelled" -> Color(0xFFC62828)
                                            else -> Color(0xFF37474F)
                                        }
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text(order.status, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }

                                DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                                    listOf("Pending", "In-Transit", "Delivered", "Cancelled").forEach { s ->
                                        DropdownMenuItem(
                                            text = { Text(s) },
                                            onClick = {
                                                viewModel.updateOrderStatus(order, s)
                                                showStatusMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Buyer, Bhatti and Cargo info
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Buyer:", fontSize = 12.sp, color = Color.Gray)
                                Text(buyer?.name ?: "Unknown Buyer", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Source Bhatti:", fontSize = 12.sp, color = Color.Gray)
                                Text(bhatti?.name ?: "Unknown Bhatti", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Transporter:", fontSize = 12.sp, color = Color.Gray)
                                Text(transporter?.companyName ?: "Direct/None", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Export Cargo weight:", fontSize = 12.sp, color = Color.Gray)
                                Text("${order.quantityTonnes} Tonnes", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Finance Summary
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Bhatti buy price", fontSize = 11.sp, color = Color.Gray)
                                Text("₹${order.buyingRatePerKg}/Kg", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Column {
                                Text("Sale price", fontSize = 11.sp, color = Color.Gray)
                                Text("₹${order.sellingRatePerKg}/Kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("Est Profit Margin", fontSize = 11.sp, color = Color.Gray)
                                Text("₹${String.format(Locale.US, "%,.0f", profitMargin)}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = if (profitMargin >= 0) Color(0xFF2E7D32) else Color.Red)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = { viewModel.deleteOrder(order) },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete Order", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: PLANNER (FOLLOW-UPS & TARGETS)
// ==========================================
@Composable
fun PlannerScreen(
    viewModel: MainViewModel,
    followUps: List<FollowUp>,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>,
    seasonTarget: SeasonTarget?,
    onEditTargetClick: () -> Unit
) {
    var showCompleted by remember { mutableStateOf(false) }

    val filteredFollowUps = followUps.filter { it.isCompleted == showCompleted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Season target edit card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Season Export Target Settings ⚙️", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    IconButton(onClick = onEditTargetClick) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit target", tint = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Target Value:", fontSize = 13.sp, color = Color.Gray)
                    Text("${seasonTarget?.targetTonnes ?: 500.0} Tonnes", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Current Achievement progress:", fontSize = 13.sp, color = Color.Gray)
                    Text("${seasonTarget?.currentProgressTonnes ?: 0.0} Tonnes", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        // Switch to see completed/pending follow-ups
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (showCompleted) "Completed Tasks Checklist ✅" else "Pending Follow-ups List ⏰",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show Completed", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.width(6.dp))
                Switch(
                    checked = showCompleted,
                    onCheckedChange = { showCompleted = it }
                )
            }
        }

        if (filteredFollowUps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (showCompleted) "Abhi tak koi task completed nahi hai." else "Hooray! Koi pending followups nahi hai. Naye log task design karne ke liye + button dabayein.",
                    fontSize = 13.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredFollowUps) { fu ->
                    val nameRef = when (fu.relatedType) {
                        "Buyer" -> buyers.find { it.id == fu.relatedId }?.name
                        "Bhatti" -> bhattis.find { it.id == fu.relatedId }?.name
                        "Transporter" -> transporters.find { it.id == fu.relatedId }?.companyName
                        else -> null
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.toggleFollowUpCompleted(fu) }) {
                            Icon(
                                imageVector = if (fu.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.Circle,
                                contentDescription = null,
                                tint = if (fu.isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fu.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (fu.description.isNotEmpty()) {
                                Text(
                                    text = fu.description,
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                            if (nameRef != null) {
                                Text(
                                    text = "Related: $nameRef (${fu.relatedType})",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = "Follow-up Date: ${fu.date}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        IconButton(onClick = { viewModel.deleteFollowUp(fu) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = Color.LightGray)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// FORM DIALOGS
// ==========================================

@Composable
fun AddBuyerDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String, location: String, category: String, prefType: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val categories = listOf("Wholesaler", "Retailer", "Sweet Manufacturer", "Food Industry")
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var catExpanded by remember { mutableStateOf(false) }

    val jaggeryTypes = listOf("Organic Cubes", "Golden Yellow Double-Filter", "Dark Solid Block", "Jaggery Powder (Organic)", "Cubes / Liquid Gur")
    var selectedJaggeryType by remember { mutableStateOf(jaggeryTypes.first()) }
    var jExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Add New Pan-India Buyer 👤", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Buyer Name / Firm Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location (e.g. Delhi, Jaipur)") }, modifier = Modifier.fillMaxWidth())

                // Category dropdown
                Text("Buyer Category", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { catExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedCategory)
                    }
                    DropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = {
                                selectedCategory = c
                                catExpanded = false
                            })
                        }
                    }
                }

                // Preferred type dropdown
                Text("Preferred Jaggery Type", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { jExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedJaggeryType)
                    }
                    DropdownMenu(expanded = jExpanded, onDismissRequest = { jExpanded = false }) {
                        jaggeryTypes.forEach { jt ->
                            DropdownMenuItem(text = { Text(jt) }, onClick = {
                                selectedJaggeryType = jt
                                jExpanded = false
                            })
                        }
                    }
                }

                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Special requirements / notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && phone.isNotEmpty()) {
                                onConfirm(name, phone, location, selectedCategory, selectedJaggeryType, notes)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Buyer") }
                }
            }
        }
    }
}

@Composable
fun AddBhattiDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, owner: String, phone: String, location: String, jaggeryType: String, stock: Double, rate: Double, notes: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var jaggeryType by remember { mutableStateOf("Organic Cubes") }
    var stock by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val jaggeryTypes = listOf("Organic Cubes", "Golden Yellow Double-Filter", "Dark Solid Block", "Jaggery Powder (Organic)", "Cubes / Liquid Gur")
    var jExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Add Local Bhatti Unit (Seller) 🏭", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Bhatti Unit Name (e.g., Patil Gur)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = owner, onValueChange = { owner = it }, label = { Text("Owner / Farmer Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Bhatti Location (e.g. Kolhapur)") }, modifier = Modifier.fillMaxWidth())

                // Jaggery Type Selector
                Text("Produced Jaggery Type", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { jExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(jaggeryType)
                    }
                    DropdownMenu(expanded = jExpanded, onDismissRequest = { jExpanded = false }) {
                        jaggeryTypes.forEach { jt ->
                            DropdownMenuItem(text = { Text(jt) }, onClick = {
                                jaggeryType = jt
                                jExpanded = false
                            })
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stock (Tonnes)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = rate, onValueChange = { rate = it }, label = { Text("Rate (₹/Kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }

                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Additional specifications") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && owner.isNotEmpty()) {
                                val sVal = stock.toDoubleOrNull() ?: 0.0
                                val rVal = rate.toDoubleOrNull() ?: 0.0
                                onConfirm(name, owner, phone, location, jaggeryType, sVal, rVal, notes)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Bhatti") }
                }
            }
        }
    }
}

@Composable
fun UpdateStockDialog(
    bhatti: Bhatti,
    onDismiss: () -> Unit,
    onConfirm: (Bhatti) -> Unit
) {
    var stock by remember { mutableStateOf(bhatti.stockTonnes.toString()) }
    var rate by remember { mutableStateOf(bhatti.ratePerKg.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Update Stock & Price: ${bhatti.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(
                    value = stock,
                    onValueChange = { stock = it },
                    label = { Text("New Stock Quantity (Tonnes)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rate,
                    onValueChange = { rate = it },
                    label = { Text("New Rate per Kg (₹/Kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val sVal = stock.toDoubleOrNull() ?: bhatti.stockTonnes
                            val rVal = rate.toDoubleOrNull() ?: bhatti.ratePerKg
                            onConfirm(bhatti.copy(stockTonnes = sVal, ratePerKg = rVal))
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Update") }
                }
            }
        }
    }
}

@Composable
fun AddTransporterDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, contact: String, phone: String, routes: String, rateKm: Double, rateTonne: Double, notes: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var routes by remember { mutableStateOf("") }
    var rateKm by remember { mutableStateOf("") }
    var rateTonne by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Add Transport Partner 🚚", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Transport Company Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Contact Person Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = routes, onValueChange = { routes = it }, label = { Text("Active Routes (e.g. Kolhapur to Delhi)") }, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = rateKm, onValueChange = { rateKm = it }, label = { Text("₹/Km Charge") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = rateTonne, onValueChange = { rateTonne = it }, label = { Text("₹/Tonne Charge") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }

                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Contract details / timing rules") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && phone.isNotEmpty()) {
                                val kmVal = rateKm.toDoubleOrNull() ?: 0.0
                                val tVal = rateTonne.toDoubleOrNull() ?: 0.0
                                onConfirm(name, contact, phone, routes, kmVal, tVal, notes)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Transporter") }
                }
            }
        }
    }
}

@Composable
fun AddOrderDialog(
    onDismiss: () -> Unit,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>,
    onConfirm: (buyerId: Int, bhattiId: Int, transporterId: Int, qty: Double, buyR: Double, sellR: Double, tCost: Double, other: Double) -> Unit
) {
    var selectedBuyer by remember { mutableStateOf<Buyer?>(null) }
    var selectedBhatti by remember { mutableStateOf<Bhatti?>(null) }
    var selectedTransporter by remember { mutableStateOf<Transporter?>(null) }

    var quantity by remember { mutableStateOf("") }
    var buyingRate by remember { mutableStateOf("") }
    var sellingRate by remember { mutableStateOf("") }
    var transportCost by remember { mutableStateOf("") }
    var otherExpenses by remember { mutableStateOf("") }

    var buyExpanded by remember { mutableStateOf(false) }
    var bhattiExpanded by remember { mutableStateOf(false) }
    var transExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Create Export Order 📦", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Select Buyer dropdown
                Text("Select Buyer", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { buyExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedBuyer?.name ?: "Select Buyer")
                    }
                    DropdownMenu(expanded = buyExpanded, onDismissRequest = { buyExpanded = false }) {
                        buyers.forEach { b ->
                            DropdownMenuItem(text = { Text("${b.name} (${b.location})") }, onClick = {
                                selectedBuyer = b
                                buyExpanded = false
                            })
                        }
                    }
                }

                // Select Bhatti dropdown
                Text("Select Bhatti Unit", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { bhattiExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedBhatti?.name ?: "Select Bhatti")
                    }
                    DropdownMenu(expanded = bhattiExpanded, onDismissRequest = { bhattiExpanded = false }) {
                        bhattis.forEach { bh ->
                            DropdownMenuItem(text = { Text("${bh.name} (${bh.jaggeryType} - ₹${bh.ratePerKg}/Kg)") }, onClick = {
                                selectedBhatti = bh
                                buyingRate = bh.ratePerKg.toString() // Auto-fill buying rate!
                                bhattiExpanded = false
                            })
                        }
                    }
                }

                // Select Transporter dropdown
                Text("Select Transporter Company", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { transExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedTransporter?.companyName ?: "Select Transporter (Optional)")
                    }
                    DropdownMenu(expanded = transExpanded, onDismissRequest = { transExpanded = false }) {
                        transporters.forEach { tr ->
                            DropdownMenuItem(text = { Text(tr.companyName) }, onClick = {
                                selectedTransporter = tr
                                transExpanded = false
                            })
                        }
                    }
                }

                OutlinedTextField(value = quantity, onValueChange = { quantity = it }, label = { Text("Cargo Quantity (Tonnes)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = buyingRate, onValueChange = { buyingRate = it }, label = { Text("Buy Rate (₹/Kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = sellingRate, onValueChange = { sellingRate = it }, label = { Text("Sell Rate (₹/Kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = transportCost, onValueChange = { transportCost = it }, label = { Text("Transport Cost (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(value = otherExpenses, onValueChange = { otherExpenses = it }, label = { Text("Other Expense (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (selectedBuyer != null && selectedBhatti != null) {
                                val qVal = quantity.toDoubleOrNull() ?: 0.0
                                val bRVal = buyingRate.toDoubleOrNull() ?: 0.0
                                val sRVal = sellingRate.toDoubleOrNull() ?: 0.0
                                val tCostVal = transportCost.toDoubleOrNull() ?: 0.0
                                val otherVal = otherExpenses.toDoubleOrNull() ?: 0.0
                                onConfirm(selectedBuyer!!.id, selectedBhatti!!.id, selectedTransporter?.id ?: 0, qVal, bRVal, sRVal, tCostVal, otherVal)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Create Order") }
                }
            }
        }
    }
}

@Composable
fun AddFollowUpDialog(
    onDismiss: () -> Unit,
    buyers: List<Buyer>,
    bhattis: List<Bhatti>,
    transporters: List<Transporter>,
    onConfirm: (title: String, desc: String, date: String, relatedType: String, relatedId: Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dateString by remember { mutableStateOf("") }

    val relatedTypes = listOf("General", "Buyer", "Bhatti", "Transporter")
    var selectedType by remember { mutableStateOf(relatedTypes.first()) }
    var typeExpanded by remember { mutableStateOf(false) }

    var relatedId by remember { mutableStateOf(0) }
    var selectEntityExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Schedule Follow-up Task ⏰", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title (e.g. Call Rajesh Ji)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Task Description / notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                // Date Picker Simple Text Input
                val datePlaceholder = SimpleDateFormat("yyyy-MM-DD", Locale.US).format(Date())
                OutlinedTextField(value = dateString, onValueChange = { dateString = it }, label = { Text("Follow-up Date (YYYY-MM-DD)") }, placeholder = { Text(datePlaceholder) }, modifier = Modifier.fillMaxWidth())

                // Related Type Dropdown
                Text("Link to Entity type", fontSize = 12.sp, color = Color.Gray)
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { typeExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                        Text(selectedType)
                    }
                    DropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                        relatedTypes.forEach { t ->
                            DropdownMenuItem(text = { Text(t) }, onClick = {
                                selectedType = t
                                relatedId = 0
                                typeExpanded = false
                            })
                        }
                    }
                }

                // Show related entity select if not general
                if (selectedType != "General") {
                    Text("Select Specific $selectedType", fontSize = 12.sp, color = Color.Gray)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        val activeSelectionName = when (selectedType) {
                            "Buyer" -> buyers.find { it.id == relatedId }?.name ?: "Select Buyer link"
                            "Bhatti" -> bhattis.find { it.id == relatedId }?.name ?: "Select Bhatti link"
                            "Transporter" -> transporters.find { it.id == relatedId }?.companyName ?: "Select Transporter link"
                            else -> "General link"
                        }

                        OutlinedButton(onClick = { selectEntityExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                            Text(activeSelectionName)
                        }

                        DropdownMenu(expanded = selectEntityExpanded, onDismissRequest = { selectEntityExpanded = false }) {
                            when (selectedType) {
                                "Buyer" -> buyers.forEach { b ->
                                    DropdownMenuItem(text = { Text(b.name) }, onClick = {
                                        relatedId = b.id
                                        selectEntityExpanded = false
                                    })
                                }
                                "Bhatti" -> bhattis.forEach { bh ->
                                    DropdownMenuItem(text = { Text(bh.name) }, onClick = {
                                        relatedId = bh.id
                                        selectEntityExpanded = false
                                    })
                                }
                                "Transporter" -> transporters.forEach { tr ->
                                    DropdownMenuItem(text = { Text(tr.companyName) }, onClick = {
                                        relatedId = tr.id
                                        selectEntityExpanded = false
                                    })
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (title.isNotEmpty()) {
                                val dString = if (dateString.isEmpty()) {
                                    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                } else {
                                    dateString
                                }
                                onConfirm(title, description, dString, selectedType, relatedId)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Task") }
                }
            }
        }
    }
}

@Composable
fun EditTargetDialog(
    currentTarget: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var targetInput by remember { mutableStateOf(currentTarget.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Edit Season Export Target 🎯", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(
                    value = targetInput,
                    onValueChange = { targetInput = it },
                    label = { Text("Season Target (Tonnes)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val targetVal = targetInput.toDoubleOrNull() ?: currentTarget
                            onConfirm(targetVal)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Settings") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiChatScreen(viewModel: MainViewModel) {
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isSendingChat by viewModel.isSendingChat.collectAsStateWithLifecycle()
    val aiTaskState by viewModel.aiTaskState.collectAsStateWithLifecycle()

    var chatInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scroll to bottom whenever list updates
    LaunchedEffect(chatMessages.size, isSendingChat) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // AI Target / Task Generator Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Vyapaar Target Generator 🎯",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Apne business ko jaldi badhane ke liye AI se personalized dynamic task lein.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    Button(
                        onClick = { viewModel.generateAiGrowthTask() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text("Get Target", fontSize = 11.sp)
                    }
                }

                // Subpanel showing Generated Task & Confirmation Controls
                AnimatedContent(
                    targetState = aiTaskState,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "TaskStateTransition"
                ) { state ->
                    when (state) {
                        is AiTaskState.Loading -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI dimaag laga raha hai... 🧠", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        is AiTaskState.Success -> {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = state.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = state.description,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(onClick = { viewModel.dismissAiTask() }) {
                                            Text("Dismiss", fontSize = 12.sp, color = Color.Gray)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = { viewModel.acceptAiGrowthTask(state.title, state.description, state.date) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Accept & Save", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                        is AiTaskState.Error -> {
                            Text(
                                text = "⚠️ Error: ${state.message}",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        is AiTaskState.Idle -> {}
                    }
                }
            }
        }

        // Active Messaging panel
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Inline status header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF2E7D32), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Gur Vyapaar Mitra 🤖", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    TextButton(onClick = { viewModel.clearChatHistory() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear History", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Main messages list
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(chatMessages) { message ->
                        val isUser = message.sender == "user"
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(
                                        RoundedCornerShape(
                                            topStart = 12.dp,
                                            topEnd = 12.dp,
                                            bottomStart = if (isUser) 12.dp else 2.dp,
                                            bottomEnd = if (isUser) 2.dp else 12.dp
                                        )
                                    )
                                    .background(
                                        if (isUser) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .widthIn(max = 280.dp)
                            ) {
                                Text(
                                    text = message.text,
                                    fontSize = 13.sp,
                                    color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (isSendingChat) {
                        item {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = 2.dp, bottomEnd = 12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("AI typing...", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Input bar with OutlinedTextField and rounded shape
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatInput,
                        onValueChange = { chatInput = it },
                        placeholder = { Text("AI se business badhane ki baten karein...") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 13.sp),
                        shape = RoundedCornerShape(24.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (chatInput.trim().isNotEmpty()) {
                                viewModel.sendChatMessage(chatInput.trim())
                                chatInput = ""
                            }
                        },
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
