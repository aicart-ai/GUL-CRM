package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface AiAdviceState {
    object Idle : AiAdviceState
    object Loading : AiAdviceState
    data class Success(val advice: String) : AiAdviceState
    data class Error(val message: String) : AiAdviceState
}

sealed interface AiTaskState {
    object Idle : AiTaskState
    object Loading : AiTaskState
    data class Success(val title: String, val description: String, val date: String) : AiTaskState
    data class Error(val message: String) : AiTaskState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = JaggeryRepository(AppDatabase.getInstance(application))

    // UI State flows
    val buyers: StateFlow<List<Buyer>> = repository.buyers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bhattis: StateFlow<List<Bhatti>> = repository.bhattis
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transporters: StateFlow<List<Transporter>> = repository.transporters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val followUps: StateFlow<List<FollowUp>> = repository.followUps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val seasonTarget: StateFlow<SeasonTarget?> = repository.seasonTargetFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current selection states
    var selectedBuyerId = MutableStateFlow<Int?>(null)
        private set

    // Active Buyer History Flow
    val activeBuyerHistory: StateFlow<List<InteractionHistory>> = selectedBuyerId
        .flatMapLatest { id ->
            if (id != null) repository.getHistoryForBuyer(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Consultation State
    private val _aiAdviceState = MutableStateFlow<AiAdviceState>(AiAdviceState.Idle)
    val aiAdviceState: StateFlow<AiAdviceState> = _aiAdviceState.asStateFlow()

    // AI Chat States
    val chatMessages: StateFlow<List<ChatMessage>> = repository.chatMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isSendingChat = MutableStateFlow(false)
    val isSendingChat: StateFlow<Boolean> = _isSendingChat.asStateFlow()

    private val _aiTaskState = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val aiTaskState: StateFlow<AiTaskState> = _aiTaskState.asStateFlow()

    init {
        // Initialize Season Target if database is empty
        viewModelScope.launch {
            val target = repository.getSeasonTarget()
            if (target == null) {
                repository.insertSeasonTarget(
                    SeasonTarget(targetTonnes = 500.0, currentProgressTonnes = 0.0, year = "2026-2027")
                )
            }

            // Populate welcome chat message if empty
            val currentChat = repository.chatMessages.firstOrNull() ?: emptyList()
            if (currentChat.isEmpty()) {
                repository.insertChatMessage(
                    ChatMessage(
                        text = "Ram Ram! Swagat hai aapka Gur Vyapaar Mitra chat pane me. 🌟 Aap mujhse apne buyers, bhattis, transportation routes ya business badhane ki tips discuss kar sakte hain. Aap ye bhi pooch sakte hain: 'Mujhe ek naya task do jisse business grow ho.' Main aapki madad ke liye taiyaar hoon!",
                        sender = "ai"
                    )
                )
            }
        }
    }

    fun prepopulateSampleData() {
        viewModelScope.launch {
            // Check if already populated to avoid duplicate entries
            val currentBuyers = repository.buyers.firstOrNull() ?: emptyList()
            if (currentBuyers.isNotEmpty()) return@launch

            // 1. Bhatti units
            val b1 = repository.insertBhatti(Bhatti(name = "Krishnat Patil Bhatti Unit", ownerName = "Krishnat Patil", phone = "9876543210", location = "Kolhapur, Maharashtra", jaggeryType = "Organic Cubes", stockTonnes = 18.5, ratePerKg = 48.0, notes = "Fully chemical-free organic jaggery. Top export quality."))
            val b2 = repository.insertBhatti(Bhatti(name = "Shetkari Gur Udyog", ownerName = "Vitthal Rao", phone = "9822334455", location = "Sangli, Maharashtra", jaggeryType = "Golden Yellow Double-Filter", stockTonnes = 35.0, ratePerKg = 42.0, notes = "High clarity, very popular in north India markets."))
            val b3 = repository.insertBhatti(Bhatti(name = "Malwa Bio-Gur bhatti", ownerName = "Suresh Sharma", phone = "9425012345", location = "Indore, Madhya Pradesh", jaggeryType = "Jaggery Powder (Organic)", stockTonnes = 10.0, ratePerKg = 55.0, notes = "Premium powder, ideal for packing in 1Kg jars."))

            // 2. Transporters
            val t1 = repository.insertTransporter(Transporter(companyName = "Maratha Roadways Ltd", contactName = "Sanjay Rane", phone = "9988776655", routes = "Kolhapur to Delhi, Mumbai, Ahmedabad", ratePerKm = 22.0, ratePerTonne = 450.0, notes = "Reliable 10-wheel trucks. Safe jaggery tarp-cover included."))
            val t2 = repository.insertTransporter(Transporter(companyName = "Jai Bharat Cargo", contactName = "Gurnam Singh", phone = "9814099887", routes = "Sangli to Delhi, Ludhiana, Amritsar", ratePerKm = 25.0, ratePerTonne = 480.0, notes = "Experienced in long-distance North India routes."))
            val t3 = repository.insertTransporter(Transporter(companyName = "Speed Logistics West", contactName = "Amit Patel", phone = "9112233445", routes = "Indore to Mumbai, Pune, Nagpur", ratePerKm = 18.0, ratePerTonne = 380.0, notes = "Best for quick delivery in West India regions."))

            // 3. Buyers
            val buy1Id = repository.insertBuyer(Buyer(name = "Rajesh Gupta Wholesalers", phone = "9311022334", location = "Naya Bazar, Delhi", category = "Wholesaler", preferredType = "Golden Yellow Double-Filter", notes = "Demands bulk quantity for festive season. Always expects prompt shipping."))
            val buy2Id = repository.insertBuyer(Buyer(name = "Pure Foods India Pvt Ltd", phone = "9820011223", location = "Andheri, Mumbai", category = "Food Industry", preferredType = "Organic Cubes", notes = "Wants clean organic jaggery for confectionery products. Strict quality requirements."))
            val buy3Id = repository.insertBuyer(Buyer(name = "Bikaner Sweets & Namkeen", phone = "9414055667", location = "Jaipur, Rajasthan", category = "Sweet Manufacturer", preferredType = "Jaggery Powder (Organic)", notes = "Uses powder for bulk sweet preparation. Looks for stable moisture levels."))

            // 4. Interaction History
            repository.insertHistory(InteractionHistory(buyerId = buy1Id.toInt(), text = "Rajesh ji se phone par baat hui. Unhone Delhi wholesale market ke liye 12 Tonne Golden Yellow Double-Filter ka specification maanga hai. Humne Shetkari Gur Udyog ki quality recommend ki."))
            repository.insertHistory(InteractionHistory(buyerId = buy1Id.toInt(), text = "Shetkari Gur ka sample Rajesh ji ke office deliver kiya. Unhone quality ko check karke bohot pasand kiya hai. Unhone deliver price Rs. 48/Kg maangi hai. Transport cost calculation baki hai."))
            repository.insertHistory(InteractionHistory(buyerId = buy2Id.toInt(), text = "Pure Foods procurement manager Shashi ji se meeting hui. Premium Organic Cubes ke samples hand-over kiye. Certification documents validation stage me hain."))

            // 5. Orders
            repository.insertOrder(Order(buyerId = buy1Id.toInt(), bhattiId = b2.toInt(), transporterId = t2.toInt(), quantityTonnes = 8.0, buyingRatePerKg = 42.0, sellingRatePerKg = 49.5, transportCost = 28000.0, otherExpenses = 4000.0, status = "In-Transit"))
            repository.insertOrder(Order(buyerId = buy2Id.toInt(), bhattiId = b1.toInt(), transporterId = t1.toInt(), quantityTonnes = 4.5, buyingRatePerKg = 48.0, sellingRatePerKg = 58.0, transportCost = 15000.0, otherExpenses = 2500.0, status = "Delivered"))

            // 6. Follow-ups
            repository.insertFollowUp(FollowUp(title = "Rajesh Gupta Delivery Update", description = "Call Sanjay (Maratha Roadways) to check Delhi truck status.", date = "2026-07-10", isCompleted = false, relatedType = "Buyer", relatedId = buy1Id.toInt()))
            repository.insertFollowUp(FollowUp(title = "Krishnat Patil Jaggery Stock", description = "Check if fresh Organic batch of 10 Tonne is ready at bhatti.", date = "2026-07-11", isCompleted = false, relatedType = "Bhatti", relatedId = b1.toInt()))
            repository.insertFollowUp(FollowUp(title = "Bikaner Sweet Mart Pricing Pitch", description = "Send quote for Jaggery Powder using Malwa Bhatti stock + Speed Logistics routes.", date = "2026-07-12", isCompleted = false, relatedType = "Buyer", relatedId = buy3Id.toInt()))

            updateProgressFromOrders()
        }
    }

    fun selectBuyer(id: Int?) {
        selectedBuyerId.value = id
        _aiAdviceState.value = AiAdviceState.Idle
    }

    // --- Buyer CRUD ---
    fun addBuyer(name: String, phone: String, location: String, category: String, preferredType: String, notes: String) {
        viewModelScope.launch {
            repository.insertBuyer(
                Buyer(name = name, phone = phone, location = location, category = category, preferredType = preferredType, notes = notes)
            )
        }
    }

    fun updateBuyer(buyer: Buyer) {
        viewModelScope.launch {
            repository.updateBuyer(buyer)
        }
    }

    fun deleteBuyer(buyer: Buyer) {
        viewModelScope.launch {
            repository.deleteBuyer(buyer)
        }
    }

    // --- Interaction History ---
    fun addInteraction(buyerId: Int, text: String) {
        viewModelScope.launch {
            repository.insertHistory(
                InteractionHistory(buyerId = buyerId, text = text)
            )
        }
    }

    fun deleteInteraction(history: InteractionHistory) {
        viewModelScope.launch {
            repository.deleteHistory(history)
        }
    }

    // --- Bhatti CRUD ---
    fun addBhatti(name: String, ownerName: String, phone: String, location: String, jaggeryType: String, stockTonnes: Double, ratePerKg: Double, notes: String) {
        viewModelScope.launch {
            repository.insertBhatti(
                Bhatti(name = name, ownerName = ownerName, phone = phone, location = location, jaggeryType = jaggeryType, stockTonnes = stockTonnes, ratePerKg = ratePerKg, notes = notes)
            )
        }
    }

    fun updateBhatti(bhatti: Bhatti) {
        viewModelScope.launch {
            repository.updateBhatti(bhatti.copy(lastUpdated = System.currentTimeMillis()))
        }
    }

    fun deleteBhatti(bhatti: Bhatti) {
        viewModelScope.launch {
            repository.deleteBhatti(bhatti)
        }
    }

    // --- Transporter CRUD ---
    fun addTransporter(companyName: String, contactName: String, phone: String, routes: String, ratePerKm: Double, ratePerTonne: Double, notes: String) {
        viewModelScope.launch {
            repository.insertTransporter(
                Transporter(companyName = companyName, contactName = contactName, phone = phone, routes = routes, ratePerKm = ratePerKm, ratePerTonne = ratePerTonne, notes = notes)
            )
        }
    }

    fun updateTransporter(transporter: Transporter) {
        viewModelScope.launch {
            repository.updateTransporter(transporter)
        }
    }

    fun deleteTransporter(transporter: Transporter) {
        viewModelScope.launch {
            repository.deleteTransporter(transporter)
        }
    }

    // --- Order CRUD ---
    fun addOrder(buyerId: Int, bhattiId: Int, transporterId: Int, quantityTonnes: Double, buyingRatePerKg: Double, sellingRatePerKg: Double, transportCost: Double, otherExpenses: Double) {
        viewModelScope.launch {
            val orderId = repository.insertOrder(
                Order(
                    buyerId = buyerId,
                    bhattiId = bhattiId,
                    transporterId = transporterId,
                    quantityTonnes = quantityTonnes,
                    buyingRatePerKg = buyingRatePerKg,
                    sellingRatePerKg = sellingRatePerKg,
                    transportCost = transportCost,
                    otherExpenses = otherExpenses,
                    status = "Pending"
                )
            )

            // Update season target progress if order is created
            updateProgressFromOrders()
        }
    }

    fun updateOrderStatus(order: Order, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrder(order.copy(status = newStatus))
            updateProgressFromOrders()
        }
    }

    fun deleteOrder(order: Order) {
        viewModelScope.launch {
            repository.deleteOrder(order)
            updateProgressFromOrders()
        }
    }

    private fun updateProgressFromOrders() {
        viewModelScope.launch {
            val currentOrders = repository.orders.firstOrNull() ?: emptyList()
            val deliveredWeight = currentOrders
                .filter { it.status == "Delivered" || it.status == "In-Transit" || it.status == "Pending" }
                .sumOf { it.quantityTonnes }

            val currentTarget = repository.getSeasonTarget()
            if (currentTarget != null) {
                repository.updateSeasonTarget(currentTarget.copy(currentProgressTonnes = deliveredWeight))
            }
        }
    }

    // --- Follow-up CRUD ---
    fun addFollowUp(title: String, description: String, date: String, relatedType: String, relatedId: Int) {
        viewModelScope.launch {
            repository.insertFollowUp(
                FollowUp(title = title, description = description, date = date, relatedType = relatedType, relatedId = relatedId)
            )
        }
    }

    fun toggleFollowUpCompleted(followUp: FollowUp) {
        viewModelScope.launch {
            repository.updateFollowUp(followUp.copy(isCompleted = !followUp.isCompleted))
        }
    }

    fun deleteFollowUp(followUp: FollowUp) {
        viewModelScope.launch {
            repository.deleteFollowUp(followUp)
        }
    }

    // --- Season Target ---
    fun updateSeasonTargetValue(newTargetTonnes: Double) {
        viewModelScope.launch {
            val current = repository.getSeasonTarget()
            if (current != null) {
                repository.updateSeasonTarget(current.copy(targetTonnes = newTargetTonnes))
            } else {
                repository.insertSeasonTarget(SeasonTarget(targetTonnes = newTargetTonnes))
            }
        }
    }

    // --- AI Smart Advisor ---
    fun getSmartAdviceForBuyer(buyer: Buyer) {
        viewModelScope.launch {
            _aiAdviceState.value = AiAdviceState.Loading
            val history = activeBuyerHistory.value
            val currentBhattis = bhattis.value
            val currentTransporters = transporters.value

            val advice = GeminiService.getBuyerAdvice(
                buyer = buyer,
                history = history,
                bhattis = currentBhattis,
                transporters = currentTransporters
            )

            if (advice.startsWith("Error:") || advice.contains("missing") || advice.contains("exception")) {
                _aiAdviceState.value = AiAdviceState.Error(advice)
            } else {
                _aiAdviceState.value = AiAdviceState.Success(advice)
            }
        }
    }

    fun clearAdvice() {
        _aiAdviceState.value = AiAdviceState.Idle
    }

    // --- AI Co-pilot Chat & Target Generator ---
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.insertChatMessage(ChatMessage(text = text, sender = "user"))
            _isSendingChat.value = true

            // Fetch chat history
            val allMessages = repository.chatMessages.firstOrNull() ?: emptyList()
            val contextInfo = buildCrmContextString()

            val response = GeminiService.chatWithGemini(allMessages, contextInfo)
            repository.insertChatMessage(ChatMessage(text = response, sender = "ai"))
            _isSendingChat.value = false
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
            repository.insertChatMessage(
                ChatMessage(
                    text = "Ram Ram! Swagat hai aapka Gur Vyapaar Mitra chat pane me. 🌟 Aap mujhse apne buyers, bhattis, transportation routes ya business badhane ki tips discuss kar sakte hain. Aap ye bhi pooch sakte hain: 'Mujhe ek naya task do jisse business grow ho.' Main aapki madad ke liye taiyaar hoon!",
                    sender = "ai"
                )
            )
        }
    }

    fun generateAiGrowthTask() {
        viewModelScope.launch {
            _aiTaskState.value = AiTaskState.Loading
            val contextInfo = buildCrmContextString()
            val todayDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

            val jsonResult = GeminiService.generateGrowthTask(contextInfo, todayDate)

            if (jsonResult.startsWith("ERROR:")) {
                _aiTaskState.value = AiTaskState.Error(jsonResult)
            } else {
                try {
                    val jsonObj = org.json.JSONObject(jsonResult)
                    val title = jsonObj.optString("title", "🎯 Jaggery Business Daily Task")
                    val desc = jsonObj.optString("description", "Follow up with buyers and check stocks.")
                    val date = jsonObj.optString("date", todayDate)
                    _aiTaskState.value = AiTaskState.Success(title, desc, date)
                } catch (e: Exception) {
                    _aiTaskState.value = AiTaskState.Error("Afsos! Task generate/parse karne me dikkat hui. Kripya naye prayas karein.")
                }
            }
        }
    }

    fun acceptAiGrowthTask(title: String, description: String, date: String) {
        viewModelScope.launch {
            repository.insertFollowUp(
                FollowUp(
                    title = title,
                    description = description,
                    date = date,
                    isCompleted = false,
                    relatedType = "General",
                    relatedId = 0
                )
            )
            _aiTaskState.value = AiTaskState.Idle
        }
    }

    fun dismissAiTask() {
        _aiTaskState.value = AiTaskState.Idle
    }

    private fun buildCrmContextString(): String {
        val buyersList = buyers.value
        val bhattisList = bhattis.value
        val transportersList = transporters.value
        val ordersList = orders.value
        val followUpsList = followUps.value

        val bStr = buyersList.joinToString("\n") { "- Buyer: ${it.name}, Loc: ${it.location}, Pref: ${it.preferredType}, Category: ${it.category}" }
        val bhStr = bhattisList.joinToString("\n") { "- Bhatti: ${it.name}, Loc: ${it.location}, Stock: ${it.stockTonnes}T, Rate: Rs.${it.ratePerKg}/Kg" }
        val tStr = transportersList.joinToString("\n") { "- Transporter: ${it.companyName}, Routes: ${it.routes}" }
        val oStr = ordersList.joinToString("\n") { "- Order: ${it.quantityTonnes}T to Buyer ID ${it.buyerId}, Status: ${it.status}" }
        val fStr = followUpsList.filter { !it.isCompleted }.joinToString("\n") { "- Pending Task: ${it.title} (Date: ${it.date})" }

        return """
            Buyers List:
            $bStr

            Bhattis (Suppliers) List:
            $bhStr

            Transporters Logistics:
            $tStr

            Current Orders Status:
            $oStr

            Current Active/Pending Tasks:
            $fStr
        """.trimIndent()
    }
}
